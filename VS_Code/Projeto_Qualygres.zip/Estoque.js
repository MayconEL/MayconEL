const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({headless: false});
  const page = await browser.newPage();
  await page.goto('http://embramaco.com.br/pedidos/index.php?check=1');
  await page.waitForTimeout(2000)
  await page.type('[name="form_user_id"]', '22457513000169')
  await page.type('[name="form_password"]', 'BUAZ123')
  await page.click('[type="submit"]')
  await page.waitForTimeout(2000)
  await page.select(Option())
  

  //await page.screenshot({ path: 'foto.png'});

  //await browser.close();
})();